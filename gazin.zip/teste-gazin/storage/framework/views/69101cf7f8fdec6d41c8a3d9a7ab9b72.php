
<?php $__env->startSection('title','Lista de Desenvolvedores'); ?>

<?php $__env->startSection('content'); ?>
<h1>Lista de Desenvolvedores</h1>
<table class="table">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Nome</th>
            <th scope="col">Email</th>
            <th scope="col">Nível</th>
            <th scope="col">Editar</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $desenvolvedors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desenvolvedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($desenvolvedor->id); ?></th>
            <th scope="row">
                <a href="<?php echo e(route('desenvolvedors.show', $desenvolvedor)); ?>"><?php echo e($desenvolvedor->nome); ?></a>
            </th>
            <th scope="row"><?php echo e($desenvolvedor->email); ?></th>
            <th scope="row"><?php echo e($desenvolvedor->nivel_nome); ?></th>
            <th>
            
                <a class="btn btn-primary" href="<?php echo e(route('desenvolvedors.edit', $desenvolvedor)); ?>">Editar</a>

            <form action="<?php echo e(route('desenvolvedors.destroy', $desenvolvedor)); ?>"
            method="POST"
            >
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>

            <button  

              class="btn btn-danger"
              type="submit"
              onclick="return confirm('Tem certeza que quer apagar?')" 
              > 
              
              APAGAR

            </button>
             </form>
            </th>
           
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a class="btn btn-success" href="<?php echo e(route('desenvolvedors.create')); ?>">Novo Desenvolvedor</a>
<a class="btn btn-primary" href="<?php echo e(route('niveis.index')); ?>">Gerenciar Níveis</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muril\Desktop\teste-gazin\resources\views/desenvolvedors/index.blade.php ENDPATH**/ ?>