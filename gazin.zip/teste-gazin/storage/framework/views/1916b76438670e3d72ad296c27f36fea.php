<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Meu App</title>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
<body>
    <div class="container">
        <?php echo e($slot); ?>

    </div>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>
</html>

<?php /**PATH C:\Users\muril\Documents\gazin\teste-gazin\resources\views/livewire/gazin-front.blade.php ENDPATH**/ ?>