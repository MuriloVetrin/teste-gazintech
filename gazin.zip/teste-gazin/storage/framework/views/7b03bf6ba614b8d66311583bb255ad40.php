
<?php $__env->startSection('title','Lista de Níveis'); ?>

<?php $__env->startSection('content'); ?>
<h1>Lista de Níveis</h1>
<table class="table">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Nome</th>
            <th scope="col">Editar</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $nivels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($nivel->id); ?></th>
            <th scope="row">
                <a href="<?php echo e(route('nivels.show', $nivel)); ?>"><?php echo e($nivel->nome); ?></a>
            </th>
            <th>
                <a class="btn btn-primary" href="<?php echo e(route('nivels.edit', $nivel)); ?>">Editar</a>

            <form action="<?php echo e(route('nivels.destroy', $nivel)); ?>"
            method="POST"
            >
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>

            <button  

              class="btn btn-danger"
              type="submit"
              onclick="return confirm('Tem certeza que quer apagar?')" 
              > 
              
              APAGAR

            </button>
             </form>
            </th>
           
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a class="btn btn-success" href="<?php echo e(route('nivels.create')); ?>">Novo nivel</a>
<a class="btn btn-secondary" href="<?php echo e(route('desenvolvedors.index')); ?>">Voltar para Lista de Desenvolvedores</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muril\Desktop\teste-gazin\resources\views/nivels/index.blade.php ENDPATH**/ ?>