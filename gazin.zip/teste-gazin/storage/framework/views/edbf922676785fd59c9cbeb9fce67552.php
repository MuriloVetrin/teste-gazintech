
<?php $__env->startSection('title', 'Adicionar Novo Desenvolvedor'); ?>
<?php $__env->startSection('content'); ?>

    <h1>Novo Desenvolvedor</h1>

    <form action="<?php echo e(route('desenvolvedors.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="nome" class="form-label">Nome</label>
            <input type="text" name="nome" id="nome" placeholder="Digite o nome" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="text" name="email" id="email" placeholder="Digite seu email" class="form-control" required>
            <?php if($errors->has('email')): ?>
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
            <?php endif; ?>
        </div>
        <div class="mb-3">
            <label for="nivel_id" class="form-label">Nível</label>
            <select name="nivel_id" id="nivel_id" class="form-control" required>
                    <option value="">Selecione o nível</option>

                <?php $__currentLoopData = $nivels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($nivel->nome); ?>"><?php echo e($nivel->nome); ?></option>
                 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button class="btn btn-success w-100" type="submit">Enviar</button>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muril\Desktop\teste-gazin\resources\views/desenvolvedors/create.blade.php ENDPATH**/ ?>