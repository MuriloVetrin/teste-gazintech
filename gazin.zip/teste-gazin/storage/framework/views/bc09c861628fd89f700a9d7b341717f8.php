
<?php $__env->startSection('title','Detalhes do nivel'); ?>

<?php $__env->startSection('content'); ?>

<div class="card" style="width: 18rem;">
    <div class="card-header">
        <?php echo e($nivel->nome); ?>

    </div>
    <div class="card-body">
        <p class="card-text"><strong>ID: </strong><?php echo e($nivel->id); ?></p>
        <p class="card-text"><strong>Nome: </strong><?php echo e($nivel->nome); ?></p>
        <p class="card-text"><strong>Quantidade de devs com esse nível: </strong><?php echo e($nivel->desenvolvedor->count()); ?></p>

        <br>
        <a href="<?php echo e(route('niveis.index')); ?>" class="btn btn-success">Voltar á lista de niveis</a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muril\Desktop\Nova pasta (3)\teste-gazin\resources\views/niveis/show.blade.php ENDPATH**/ ?>