
<?php $__env->startSection('title','Detalhes do desenvolvedor'); ?>

<?php $__env->startSection('content'); ?>

<div class="card" style="width: 18rem;">
    <div class="card-header">
        <?php echo e($desenvolvedor->nome); ?>

    </div>
    <div class="card-body">
        <p class="card-text"><strong>ID: </strong><?php echo e($desenvolvedor->id); ?></p>
        <p class="card-text"><strong>Nome: </strong><?php echo e($desenvolvedor->nome); ?></p>
        <p class="card-text"><strong>Email: </strong><?php echo e($desenvolvedor->email); ?></p>
        <p class="card-text"><strong>Nível: </strong><?php echo e($desenvolvedor->nivel); ?></p>
        <br>
        <a class="btn btn-success" href="<?php echo e(route('desenvolvedors.index')); ?>" class="btn btn-success">Voltar á lista de Desenvolvedor</a>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muril\Desktop\teste-gazin\resources\views/desenvolvedors/show.blade.php ENDPATH**/ ?>