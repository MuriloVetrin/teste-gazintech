
<?php $__env->startSection('title','Lista de Desenvolvedores'); ?>

<?php $__env->startSection('content'); ?>
<h1>Lista de Desenvolvedores</h1>
<table class="table">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Nome</th>
            <th scope="col">Email</th>
            <th scope="col">Nível</th>
            <th scope="col">Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $devs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($dev->id); ?></th>
            <th scope="row">
                <a href="<?php echo e(route('desenvolvedor.show', $dev)); ?>"><?php echo e($dev->nome); ?></a>
            </th>
            <th scope="row"><?php echo e($dev->email); ?></th>
            <th>
            
                <a class="btn btn-primary" href="<?php echo e(route('desenvolvedor.edit', $dev)); ?>">Editar</a>

            <form action="<?php echo e(route('desenvolvedor.destroy', $dev)); ?>"
            method="POST"
            >
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>

            <button  

              class="btn btn-danger"
              type="submit"
              onclick="return confirm('Tem certeza que quer apagar?')" 
              > 
              
              APAGAR

            </button>
             </form>
            </th>
           
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<a class="btn btn-success" href="<?php echo e(route('desenvolvedor.create')); ?>">Novo Desenvolvedor</a>
<a class="btn btn-primary" href="<?php echo e(route('nivel.index')); ?>">Gerenciar Níveis</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muril\Documents\gazin\teste-gazin\resources\views/desenvolvedor/index.blade.php ENDPATH**/ ?>