<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    </head>
    <body>
        <div id="app">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <script src="<?php echo e(mix('js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\Users\muril\Desktop\Nova pasta (3)\teste-gazin\resources\views/sobre/index.blade.php ENDPATH**/ ?>