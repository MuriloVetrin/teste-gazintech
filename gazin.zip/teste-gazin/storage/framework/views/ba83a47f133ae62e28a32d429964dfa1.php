<!DOCTYPE html>
<html>
<head>
	<title>Teste GazinTech</title>
	Crud de Desenvolvedores
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
	
</head>
<body>
	<button>Botão 1</button>
	<button>Botão 2</button>
</body>
</html>
<?php /**PATH C:\Users\muril\Documents\gazin\teste-gazin\resources\views/home.blade.php ENDPATH**/ ?>