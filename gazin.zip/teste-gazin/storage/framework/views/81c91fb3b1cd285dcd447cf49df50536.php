
<?php $__env->startSection('title', 'Editar Nível'); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('niveis.update', $nivel)); ?>" method="POST">
         <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="nome" class="form-label">Nome</label>
            <input type="text" name="nome" id="nome" placeholder="Digite o nome" value="<?php echo e($nivel->nome); ?>"
                class="form-control" required>
        </div>
    
        </div>
        <button class="btn btn-success w-100" type="submit">Enviar</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\muril\Desktop\Nova pasta\teste-gazin\resources\views/niveis/edit.blade.php ENDPATH**/ ?>