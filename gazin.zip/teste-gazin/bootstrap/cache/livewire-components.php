<?php return array (
  'gazin-front' => 'App\\Http\\Livewire\\GazinFront',
);